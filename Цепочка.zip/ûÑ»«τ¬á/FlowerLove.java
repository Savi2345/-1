public class FlowerLove {
    public static void main(String[] args) {
        FlowerSaleHandler cashier = new Cashier();
        FlowerSaleHandler manager = new Manager();
        FlowerSaleHandler owner = new Owner();

        cashier.setNextHandler(manager);
        manager.setNextHandler(owner);

        cashier.sellFlowers(5);
        cashier.sellFlowers(15);
        cashier.sellFlowers(25);
    }
}