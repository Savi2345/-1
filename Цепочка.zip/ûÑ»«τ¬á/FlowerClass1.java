
class Owner implements FlowerSaleHandler {
    private FlowerSaleHandler nextHandler;

    @Override
    public void setNextHandler(FlowerSaleHandler handler) {
        nextHandler = handler;
    }

    @Override
    public void sellFlowers(int amount) {
        if (amount <= 30) {
            System.out.println("Владелец: Продажа " + amount + " цветов");
        } else {
            System.out.println("Владелец: Невозможно продать " + amount + " цветов");
        }
    }
}