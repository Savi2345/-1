interface FlowerSaleHandler {
    void setNextHandler(FlowerSaleHandler handler);
    void sellFlowers(int amount);
}

class Cashier implements FlowerSaleHandler {
    private FlowerSaleHandler nextHandler;

    @Override
    public void setNextHandler(FlowerSaleHandler handler) {
        nextHandler = handler;
    }

    @Override
    public void sellFlowers(int amount) {
        if (amount <= 10) {
            System.out.println("Кассир: Продажа " + amount + " цветов");
        } else if (nextHandler != null) {
            System.out.println("Кассир: переход к следующей обработке");
            nextHandler.sellFlowers(amount);
        } else {
            System.out.println("Кассир: Невозможно продать " + amount + " цветов");
        }
    }
}



