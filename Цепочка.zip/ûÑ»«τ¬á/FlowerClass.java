class Manager implements FlowerSaleHandler {
    private FlowerSaleHandler nextHandler;

    @Override
    public void setNextHandler(FlowerSaleHandler handler) {
        nextHandler = handler;
    }

    @Override
    public void sellFlowers(int amount) {
        if (amount <= 20) {
            System.out.println("Менеджер: Продажа " + amount + " цветов");
        } else if (nextHandler != null) {
            System.out.println("Менеджер: переход к следующей обработке");
            nextHandler.sellFlowers(amount);
        } else {
            System.out.println("Менеджер: Невозможно продать " + amount + " цветов");
        }
    }
}