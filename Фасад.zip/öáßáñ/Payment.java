class Payment {
    public void processPayment() {
        System.out.println("Обработка платежа");
    }
}
