class Pricing {
    public void calculatePrice() {
        System.out.println("Расчёт стоимости цветов");
    }
}



