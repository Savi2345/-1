class FlowerSupplier {
    public void getFlowers() {
        System.out.println("Получение цветов от поставщика");
    }
}

class Inventory {
    public void updateInventory() {
        System.out.println("Обновление инвентаря");
    }
}

class Pricing {
    public void calculatePrice() {
        System.out.println("Расчёт стоимости цветов");
    }
}

class Payment {
    public void processPayment() {
        System.out.println("Обработка платежей");
    }
}

