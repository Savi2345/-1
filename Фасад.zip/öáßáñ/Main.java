class FlowerSupplier {
    public void getFlowers() {
        System.out.println("Getting flowers from supplier");
    }
}

class Inventory {
    public void updateInventory() {
        System.out.println("Updating inventory");
    }
}

class Pricing {
    public void calculatePrice() {
        System.out.println("Calculating price for flowers");
    }
}

class Payment {
    public void processPayment() {
        System.out.println("Processing payment");
    }
}



