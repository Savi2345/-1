class FlowerSupplier {
    public void getFlowers() {
        System.out.println("Получение цветов от поставщика");
    }
}
