class FlowerShopFacade {
    private FlowerSupplier flowerSupplier;
    private Inventory inventory;
    private Pricing pricing;
    private Payment payment;

    public FlowerShopFacade() {
        this.flowerSupplier = new FlowerSupplier();
        this.inventory = new Inventory();
        this.pricing = new Pricing();
        this.payment = new Payment();
    }

    public void sellFlowers() {
        flowerSupplier.getFlowers();
        inventory.updateInventory();
        pricing.calculatePrice();
        payment.processPayment();
        System.out.println("Цветы проданы");
    }
}