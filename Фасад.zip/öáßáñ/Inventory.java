class Inventory {
    public void updateInventory() {
        System.out.println("Загруска Инвенторя");
    }
}
