public class Flower {
    public static void main(String[] args) {
        FlowerShopFacade flowerShop = new FlowerShopFacade();
        flowerShop.sellFlowers();
    }
}