
public class FlowerLove {
    public static void main(String[] args) {
        FlowerShopFacade flowerShop = new FlowerShopFacade();
        flowerShop.sellFlowers();
    }
}