interface Flower {
    void display();
}

interface Accessory {
    void display();
}

class Rose implements Flower {
    @Override
    public void display() {
        System.out.println("Роза");
    }
}

class Lily implements Flower {
    @Override
    public void display() {
        System.out.println("Лилия");
    }
}

class Ribbon implements Accessory {
    @Override
    public void display() {
        System.out.println("Летна");
    }
}

class WrappingPaper implements Accessory {
    @Override
    public void display() {
        System.out.println("Упаковочная бумага");
    }
}


