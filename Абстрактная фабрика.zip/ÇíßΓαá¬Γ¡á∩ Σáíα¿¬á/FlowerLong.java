public class FlowerLong {
    public static void main(String[] args) {
        FlowerAccessoryFactory roseRibbonFactory = new RoseRibbonFactory();
        Flower rose = roseRibbonFactory.createFlower();
        Accessory ribbon = roseRibbonFactory.createAccessory();

        rose.display();
        ribbon.display();

        FlowerAccessoryFactory lilyWrappingPaperFactory = new LilyWrappingPaperFactory();
        Flower lily = lilyWrappingPaperFactory.createFlower();
        Accessory wrappingPaper = lilyWrappingPaperFactory.createAccessory();

        lily.display();
        wrappingPaper.display();
    }
}



