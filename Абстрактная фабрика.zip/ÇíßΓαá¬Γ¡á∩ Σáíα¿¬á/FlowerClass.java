interface FlowerAccessoryFactory {
    Flower createFlower();
    Accessory createAccessory();
}

class RoseRibbonFactory implements FlowerAccessoryFactory {
    @Override
    public Flower createFlower() {
        return new Rose();
    }

    @Override
    public Accessory createAccessory() {
        return new Ribbon();
    }
}

class LilyWrappingPaperFactory implements FlowerAccessoryFactory {
    @Override
    public Flower createFlower() {
        return new Lily();
    }

    @Override
    public Accessory createAccessory() {
        return new WrappingPaper();
    }
}
